import fetch from "node-fetch";

const api = {
  xterm: {
    url: "https://api.termai.cc",
    key: process.env.XTERM_APIKEY || "TermAI-4ALwMabCh0KiN9I3"
  }
};

async function enhance(imageurl, type = "cf") {
  let tryCount = 0;

  // create task
  const task = await fetch(
    `${api.xterm.url}/api/tools/enhance/createTask?url=${encodeURIComponent(imageurl)}&type=${type}&key=${api.xterm.key}`
  ).then(res => res.json());

  if (!task.status) return task;

  // check status
  while (tryCount < 50) {
    tryCount++;

    const status = await fetch(
      `${api.xterm.url}/api/tools/enhance/taskStatus?id=${task.id}`
    ).then(res => res.json());

    if (status.task_status === "failed") {
      return {
        status: false,
        msg: "Gagal enhance gambar, coba gambar lain"
      };
    }

    if (status.task_status === "done") {
      return status;
    }

    await new Promise(r => setTimeout(r, 1000));
  }

  return {
    status: false,
    msg: "Timeout saat memproses gambar"
  };
}

export default async function handler(req, res) {
  const { url, type } = req.query;

  if (!url) {
    return res.status(400).json({
      status: false,
      msg: "Parameter url wajib diisi"
    });
  }

  try {
    const result = await enhance(url, type || "cf");
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({
      status: false,
      msg: "Server error",
      error: err.message
    });
  }
}